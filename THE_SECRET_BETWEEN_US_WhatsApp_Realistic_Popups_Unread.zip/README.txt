THE SECRET BETWEEN US — Auto Type + WhatsApp Receipts & Unread

Cara pakai:
1. Extract seluruh ZIP ke satu folder.
2. Buka index.html atau upload seluruh isi folder ke hosting HTTPS.
3. Unlock ponsel simulasi dengan PIN 0303.
4. Buka WhatsApp lalu pilih room chat. Pesan cerita tampil bertahap; pesan Sabifa diketik otomatis lewat keyboard palsu.
5. Keluar dari room dan masuk lagi untuk melanjutkan dari pesan terakhir yang tersimpan.
6. Pesan keluar memiliki tanda centang ganda: abu-abu untuk terkirim dan biru ketika sudah dibaca dalam alur chat.
7. Pesan terjadwal yang datang saat room tidak dibuka akan menambah badge hijau unread. Membuka room menandai pesan sebagai sudah dibaca dan menghapus badge.
8. Pesan fiksi terjadwal mengikuti jam lokal perangkat: 07:05 Liam, 08:03 grup/Kevan, 12:30 Rengga, 17:45 Saen, 22:17 Unknown.
9. Jika website pertama kali dibuka setelah waktu jadwal lewat, notifikasi yang terlewat akan muncul sebagai banner satu per satu dan pesannya disimpan ke room yang benar.
10. Tombol "Aktifkan notifikasi browser" meminta izin notifikasi sistem bila browser/hosting mendukungnya.

Catatan:
- Jadwal dicek ketika website terbuka/aktif; website statis tidak bisa menjalankan timer saat benar-benar ditutup.
- Notifikasi sistem biasanya membutuhkan HTTPS dan izin browser. Banner simulasi di dalam website tetap bekerja saat halaman aktif.
- Data chat dan unread tersimpan di localStorage browser/perangkat yang sama.


SISTEM CHAPTER HARIAN:
- Prolog–Chapter 3 sudah terbuka pada hari pertama (29 Oktober 2026, sesuai tanggal awal cerita di file).
- Chapter 4 terbuka otomatis pada pukul 00.00 waktu lokal perangkat pada hari berikutnya.
- Setiap chapter berikutnya terbuka satu per hari pada pukul 00.00 waktu lokal perangkat, sampai Epilog.
- Jika website tetap terbuka melewati tengah malam, sistem akan mendeteksi chapter baru dan memperbarui room WhatsApp tanpa menghapus progres yang tersimpan.
- Jadwal memakai kalender lokal perangkat; jangan ubah tanggal awal cerita kecuali ingin mengatur ulang hari pertama.
